﻿namespace TBP_verzija_2
{
    partial class PodsjetniciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgZalijevanje = new System.Windows.Forms.DataGridView();
            this.dgPrihrani = new System.Windows.Forms.DataGridView();
            this.dgPresadi = new System.Windows.Forms.DataGridView();
            this.btnNatrag = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgZalijevanje)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrihrani)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPresadi)).BeginInit();
            this.SuspendLayout();
            // 
            // dgZalijevanje
            // 
            this.dgZalijevanje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgZalijevanje.Location = new System.Drawing.Point(199, 22);
            this.dgZalijevanje.Name = "dgZalijevanje";
            this.dgZalijevanje.RowHeadersWidth = 51;
            this.dgZalijevanje.RowTemplate.Height = 24;
            this.dgZalijevanje.Size = new System.Drawing.Size(477, 150);
            this.dgZalijevanje.TabIndex = 0;
            // 
            // dgPrihrani
            // 
            this.dgPrihrani.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPrihrani.Location = new System.Drawing.Point(199, 200);
            this.dgPrihrani.Name = "dgPrihrani";
            this.dgPrihrani.RowHeadersWidth = 51;
            this.dgPrihrani.RowTemplate.Height = 24;
            this.dgPrihrani.Size = new System.Drawing.Size(477, 150);
            this.dgPrihrani.TabIndex = 1;
            // 
            // dgPresadi
            // 
            this.dgPresadi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPresadi.Location = new System.Drawing.Point(199, 396);
            this.dgPresadi.Name = "dgPresadi";
            this.dgPresadi.RowHeadersWidth = 51;
            this.dgPresadi.RowTemplate.Height = 24;
            this.dgPresadi.Size = new System.Drawing.Size(477, 150);
            this.dgPresadi.TabIndex = 2;
            // 
            // btnNatrag
            // 
            this.btnNatrag.Location = new System.Drawing.Point(27, 510);
            this.btnNatrag.Name = "btnNatrag";
            this.btnNatrag.Size = new System.Drawing.Size(82, 36);
            this.btnNatrag.TabIndex = 3;
            this.btnNatrag.Text = "<-";
            this.btnNatrag.UseVisualStyleBackColor = true;
            this.btnNatrag.Click += new System.EventHandler(this.btnNatrag_Click);
            // 
            // PodsjetniciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 627);
            this.Controls.Add(this.btnNatrag);
            this.Controls.Add(this.dgPresadi);
            this.Controls.Add(this.dgPrihrani);
            this.Controls.Add(this.dgZalijevanje);
            this.Name = "PodsjetniciForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PodsjetniciForm";
            this.Load += new System.EventHandler(this.PodsjetniciForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgZalijevanje)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrihrani)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPresadi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgZalijevanje;
        private System.Windows.Forms.DataGridView dgPrihrani;
        private System.Windows.Forms.DataGridView dgPresadi;
        private System.Windows.Forms.Button btnNatrag;
    }
}