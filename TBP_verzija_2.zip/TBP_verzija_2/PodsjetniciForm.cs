﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class PodsjetniciForm : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        
        public PodsjetniciForm()
        {
            InitializeComponent();
        }

        private void PodsjetniciForm_Load(object sender, EventArgs e)
        {
            Zalij();
            Prihrani();
            Presadi();
            
        }


        private void Zalij()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var query = @"
                SELECT p.datum as Datum, p.aktivnost as Obavi, b.ime AS Biljka
                FROM podsjetnik p
                JOIN biljka b ON p.biljka_id = b.biljka_id
                WHERE p.aktivnost = 'Zalijevanje' AND p.datum >= CURRENT_DATE";

                using (var adapter = new NpgsqlDataAdapter(query, conn))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgZalijevanje.DataSource = dataTable;
                }
            }
        }

        private void Prihrani()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var query = @"
                SELECT p.datum as Datum, p.aktivnost as Obavi, b.ime AS Biljka
                FROM podsjetnik p
                JOIN biljka b ON p.biljka_id = b.biljka_id
                WHERE p.aktivnost = 'Prihranjivanje' AND p.datum >= CURRENT_DATE";

                using (var adapter = new NpgsqlDataAdapter(query, conn))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgPrihrani.DataSource = dataTable;
                }
            }
        }

        private void Presadi()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var query = @"
                SELECT p.datum as Datum, p.aktivnost as Obavi, b.ime AS Biljka
                FROM podsjetnik p
                JOIN biljka b ON p.biljka_id = b.biljka_id
                WHERE p.aktivnost = 'Presađivanje' AND p.datum >= CURRENT_DATE";

                using (var adapter = new NpgsqlDataAdapter(query, conn))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgPresadi.DataSource = dataTable;
                }
            }
        }

        private void btnNatrag_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

