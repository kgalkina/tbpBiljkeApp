﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class FormaSlike : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        private int odabranaBiljka;
        
        public FormaSlike(int biljkaID)
        {
            InitializeComponent();
            odabranaBiljka = biljkaID;
        }

        private void FormaSlike_Load(object sender, EventArgs e)
        {
            UcitajSlike();
        }
        private void UcitajSlike()
        {
            
            
            using (var conn = new NpgsqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT s.slika_id, b.ime AS NazivBiljke, s.slikica AS Slikica, s.opis AS Opis, s.datum AS Datum " +
                                  "FROM slika s " +
                                  "JOIN biljka b ON s.biljka_id = b.biljka_id " +
                                  "WHERE s.biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", odabranaBiljka);

                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            using (var dataTable = new DataTable())
                            {
                                adapter.Fill(dataTable);
                                dataGridView1.DataSource = dataTable;
                                
                                var slikicaColumn = dataGridView1.Columns["Slikica"] as DataGridViewImageColumn;
                                dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                                
                                if (slikicaColumn != null)
                                {
                                    
                                    slikicaColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                                    
                                }
                                
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Greška prilikom učitavanja slika: " + ex.Message);
                }
            }
        }

        private void btnOdaberi_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = new Bitmap(ofd.FileName);
                    pictureBox1.Tag = ofd.FileName;

                }
            }


        }

        private void btnSpremi_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null) 
            {
                byte[] novaSlika;
                using (FileStream fs = new FileStream(pictureBox1.Tag.ToString(), FileMode.Open, FileAccess.Read))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        novaSlika = br.ReadBytes((int)fs.Length);
                    }
                }

                try
                {
                    using (var conn = new NpgsqlConnection(connectionString))
                    {
                        conn.Open();
                        string query = "INSERT INTO slika (biljka_id, slikica, opis) VALUES (@id_biljke, @slika, @opis)";
                        using (var cmd = new NpgsqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@id_biljke", odabranaBiljka);
                            cmd.Parameters.AddWithValue("@slika", novaSlika);
                            cmd.Parameters.AddWithValue("@opis", textBox1.Text);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    UcitajSlike();
                    MessageBox.Show("Slika uspješno dodana.");
                }
                catch(Exception ex)
                {

                    MessageBox.Show("Greška kod dodavanja slike: " + ex.Message);
                }
                
            }
            else
            {
                MessageBox.Show("Odaberite sliku.");
            }

        }

        private void btnObrisiSliku_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                if (selectedRow.Cells["slika_id"].Value != DBNull.Value)
                {
                    int slikaId = Convert.ToInt32(selectedRow.Cells["slika_id"].Value);

                    using (var conn = new NpgsqlConnection(connectionString))
                    {
                        try
                        {
                            conn.Open();
                            string query = "DELETE FROM slika WHERE slika_id = @slikaId";

                            using (var cmd = new NpgsqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@slikaId", slikaId);
                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Slika je uspješno obrisana.");
                                UcitajSlike();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Greška prilikom brisanja slike: " + ex.Message);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Odaberite sliku za brisanje.");
                }
            }
            else
            {
                MessageBox.Show("Nema odabrane slike za brisanje.");
            }
        }
    }
    
}
