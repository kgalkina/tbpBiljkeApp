﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class AzurirajBiljkuForma : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        private int chosenOne;
        public AzurirajBiljkuForma(int odabranaBiljka)
        {
            InitializeComponent();
            chosenOne = odabranaBiljka;
        }

        private void AzurirajBiljkuForma_Load(object sender, EventArgs e)
        {
            DohvatiPodatke();
        }
        private void DohvatiPodatke()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"SELECT ime, vrsta, datum_sadnje, zalijevanje, prihranjivanje, 
                    presadivanje, min_temp, max_temp, min_vlaga, max_vlaga, dodatno 
                    FROM biljka WHERE biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", chosenOne);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                
                                textBox1.Text = reader["ime"].ToString();
                                textBox2.Text = reader["vrsta"].ToString();
                                dateTimePicker1.Value = Convert.ToDateTime(reader["datum_sadnje"]);
                                textBox3.Text = reader["zalijevanje"].ToString();
                                textBox4.Text = reader["prihranjivanje"].ToString();
                                textBox5.Text = reader["presadivanje"].ToString();
                                textBox6.Text = reader["min_temp"].ToString();
                                textBox7.Text = reader["max_temp"].ToString();
                                textBox8.Text = reader["min_vlaga"].ToString();
                                textBox9.Text = reader["max_vlaga"].ToString();
                                textBox10.Text = reader["dodatno"].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom učitavanja podataka o biljci: " + ex.Message);
            }
        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnAzuriraj_Click(object sender, EventArgs e)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    
                    string query = @"UPDATE biljka SET 
                                    ime = @ime, 
                                    vrsta = @vrsta, 
                                    datum_sadnje = @datumSadnje, 
                                    zalijevanje = @zalijevanje, 
                                    prihranjivanje = @prihranjivanje, 
                                    presadivanje = @presadivanje, 
                                    min_temp = @minTemp, 
                                    max_temp = @maxTemp, 
                                    min_vlaga = @minVlaga, 
                                    max_vlaga = @maxVlaga, 
                                    dodatno = @dodatno 
                                 WHERE biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {

                        cmd.Parameters.AddWithValue("@ime", textBox1.Text);
                        cmd.Parameters.AddWithValue("@vrsta", textBox2.Text);
                        cmd.Parameters.AddWithValue("@datumSadnje", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@zalijevanje", int.Parse(textBox3.Text));
                        cmd.Parameters.AddWithValue("@prihranjivanje", int.Parse(textBox4.Text));
                        cmd.Parameters.AddWithValue("@presadivanje", int.Parse(textBox5.Text));
                        cmd.Parameters.AddWithValue("@minTemp", float.Parse(textBox6.Text));
                        cmd.Parameters.AddWithValue("@maxTemp", float.Parse(textBox7.Text));
                        cmd.Parameters.AddWithValue("@minVlaga", int.Parse(textBox8.Text));
                        cmd.Parameters.AddWithValue("@maxVlaga", int.Parse(textBox9.Text));
                        cmd.Parameters.AddWithValue("@dodatno", textBox10.Text);
                        cmd.Parameters.AddWithValue("@biljkaId", chosenOne);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Podaci o biljci uspješno ažurirani.");

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom ažuriranja biljke: " + ex.Message);
            }
        }
    }
    
}
