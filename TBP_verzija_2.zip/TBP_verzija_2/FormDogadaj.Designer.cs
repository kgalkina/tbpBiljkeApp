﻿namespace TBP_verzija_2
{
    partial class FormDogadaj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDogadaji = new System.Windows.Forms.DataGridView();
            this.comboBoxBiljke = new System.Windows.Forms.ComboBox();
            this.comboBoxTipovi = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnNatrag = new System.Windows.Forms.Button();
            this.btnFiltriraj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDogadaji)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDogadaji
            // 
            this.dgvDogadaji.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDogadaji.Location = new System.Drawing.Point(22, 24);
            this.dgvDogadaji.Name = "dgvDogadaji";
            this.dgvDogadaji.RowHeadersWidth = 51;
            this.dgvDogadaji.RowTemplate.Height = 24;
            this.dgvDogadaji.Size = new System.Drawing.Size(625, 264);
            this.dgvDogadaji.TabIndex = 0;
            // 
            // comboBoxBiljke
            // 
            this.comboBoxBiljke.FormattingEnabled = true;
            this.comboBoxBiljke.Location = new System.Drawing.Point(725, 75);
            this.comboBoxBiljke.Name = "comboBoxBiljke";
            this.comboBoxBiljke.Size = new System.Drawing.Size(121, 24);
            this.comboBoxBiljke.TabIndex = 1;
            // 
            // comboBoxTipovi
            // 
            this.comboBoxTipovi.FormattingEnabled = true;
            this.comboBoxTipovi.Location = new System.Drawing.Point(942, 75);
            this.comboBoxTipovi.Name = "comboBoxTipovi";
            this.comboBoxTipovi.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTipovi.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(725, 246);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(726, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Odaberi biljku:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(945, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Odaberi događaj:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(728, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Datum izvršenja:";
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(725, 312);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(176, 46);
            this.btnDodaj.TabIndex = 7;
            this.btnDodaj.Text = "Dodaj događaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnNatrag
            // 
            this.btnNatrag.Location = new System.Drawing.Point(31, 463);
            this.btnNatrag.Name = "btnNatrag";
            this.btnNatrag.Size = new System.Drawing.Size(88, 47);
            this.btnNatrag.TabIndex = 9;
            this.btnNatrag.Text = "<=";
            this.btnNatrag.UseVisualStyleBackColor = true;
            this.btnNatrag.Click += new System.EventHandler(this.btnNatrag_Click);
            // 
            // btnFiltriraj
            // 
            this.btnFiltriraj.Location = new System.Drawing.Point(473, 315);
            this.btnFiltriraj.Name = "btnFiltriraj";
            this.btnFiltriraj.Size = new System.Drawing.Size(174, 43);
            this.btnFiltriraj.TabIndex = 10;
            this.btnFiltriraj.Text = "Filtriraj prema biljci";
            this.btnFiltriraj.UseVisualStyleBackColor = true;
            this.btnFiltriraj.Click += new System.EventHandler(this.btnFiltriraj_Click);
            // 
            // FormDogadaj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1097, 540);
            this.Controls.Add(this.btnFiltriraj);
            this.Controls.Add(this.btnNatrag);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBoxTipovi);
            this.Controls.Add(this.comboBoxBiljke);
            this.Controls.Add(this.dgvDogadaji);
            this.Name = "FormDogadaj";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormDogadaj";
            this.Load += new System.EventHandler(this.FormDogadaj_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDogadaji)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDogadaji;
        private System.Windows.Forms.ComboBox comboBoxBiljke;
        private System.Windows.Forms.ComboBox comboBoxTipovi;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnNatrag;
        private System.Windows.Forms.Button btnFiltriraj;
    }
}