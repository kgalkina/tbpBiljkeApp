﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


namespace TBP_verzija_2
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        private int zalijevanje, prihranjivanje, presadivanje, biljkeUkupno;

        private void btnPodsjetnici_Click(object sender, EventArgs e)
        {
            PodsjetniciForm podForm=new PodsjetniciForm();
            podForm.ShowDialog();
            
            if (podForm.DialogResult == DialogResult.OK)
            {
                
                DohvatiUkupno();
            }
        }

        private void btnBiljke_Click(object sender, EventArgs e)
        {
            BiljkeMain main = new BiljkeMain();
            main.ShowDialog();
            
            if (main.DialogResult == DialogResult.OK)
            {
                DohvatiUkupno();
                label2.Text = $"Ukupan broj biljaka: {biljkeUkupno}";
                label3.Text = $"Zalijevanje: {zalijevanje}";
                label4.Text = $"Prihranjivanje: {prihranjivanje}";
                label5.Text = $"Presađivanje: {presadivanje}";

            }
        }

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DohvatiUkupno();
            label2.Text = $"Ukupan broj biljaka: {biljkeUkupno}";
            label3.Text = $"Zalijevanje: {zalijevanje}";
            label4.Text = $"Prihranjivanje: {prihranjivanje}";
            label5.Text = $"Presađivanje: {presadivanje}";
        }
        public void DohvatiUkupno()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                
                using (var cmd = new NpgsqlCommand("SELECT COUNT(*) FROM biljka", conn))
                {
                    biljkeUkupno = Convert.ToInt32(cmd.ExecuteScalar());
                }

                
                using (var cmd = new NpgsqlCommand("SELECT * FROM ukupno_dogadaja", conn))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            zalijevanje = reader.GetInt32(0);
                            prihranjivanje = reader.GetInt32(1);
                            presadivanje = reader.GetInt32(2);
                        }
                    }
                }


            }
        }
    }
}
