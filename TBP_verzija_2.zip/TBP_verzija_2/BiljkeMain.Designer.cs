﻿namespace TBP_verzija_2
{
    partial class BiljkeMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnDodajBiljku = new System.Windows.Forms.Button();
            this.btnAzurirajBiljku = new System.Windows.Forms.Button();
            this.btnObrisiBiljku = new System.Windows.Forms.Button();
            this.btnSlike = new System.Windows.Forms.Button();
            this.btnDogadaj = new System.Windows.Forms.Button();
            this.btnUnesiLog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnNatrag = new System.Windows.Forms.Button();
            this.btnPovijest = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(55, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(923, 263);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(55, 347);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(767, 204);
            this.dataGridView2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(55, 588);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(200, 588);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(90, 22);
            this.textBox2.TabIndex = 3;
            // 
            // btnDodajBiljku
            // 
            this.btnDodajBiljku.Location = new System.Drawing.Point(1014, 67);
            this.btnDodajBiljku.Name = "btnDodajBiljku";
            this.btnDodajBiljku.Size = new System.Drawing.Size(109, 55);
            this.btnDodajBiljku.TabIndex = 4;
            this.btnDodajBiljku.Text = "Dodaj biljku";
            this.btnDodajBiljku.UseVisualStyleBackColor = true;
            this.btnDodajBiljku.Click += new System.EventHandler(this.btnDodajBiljku_Click);
            // 
            // btnAzurirajBiljku
            // 
            this.btnAzurirajBiljku.Location = new System.Drawing.Point(1014, 141);
            this.btnAzurirajBiljku.Name = "btnAzurirajBiljku";
            this.btnAzurirajBiljku.Size = new System.Drawing.Size(109, 50);
            this.btnAzurirajBiljku.TabIndex = 5;
            this.btnAzurirajBiljku.Text = "Ažuriraj biljku";
            this.btnAzurirajBiljku.UseVisualStyleBackColor = true;
            this.btnAzurirajBiljku.Click += new System.EventHandler(this.btnAzurirajBiljku_Click);
            // 
            // btnObrisiBiljku
            // 
            this.btnObrisiBiljku.Location = new System.Drawing.Point(1014, 211);
            this.btnObrisiBiljku.Name = "btnObrisiBiljku";
            this.btnObrisiBiljku.Size = new System.Drawing.Size(109, 48);
            this.btnObrisiBiljku.TabIndex = 6;
            this.btnObrisiBiljku.Text = "Obriši biljku";
            this.btnObrisiBiljku.UseVisualStyleBackColor = true;
            this.btnObrisiBiljku.Click += new System.EventHandler(this.btnObrisiBiljku_Click);
            // 
            // btnSlike
            // 
            this.btnSlike.Location = new System.Drawing.Point(1014, 276);
            this.btnSlike.Name = "btnSlike";
            this.btnSlike.Size = new System.Drawing.Size(109, 54);
            this.btnSlike.TabIndex = 7;
            this.btnSlike.Text = "Prikaži slike";
            this.btnSlike.UseVisualStyleBackColor = true;
            this.btnSlike.Click += new System.EventHandler(this.btnSlike_Click);
            // 
            // btnDogadaj
            // 
            this.btnDogadaj.Location = new System.Drawing.Point(869, 422);
            this.btnDogadaj.Name = "btnDogadaj";
            this.btnDogadaj.Size = new System.Drawing.Size(109, 50);
            this.btnDogadaj.TabIndex = 8;
            this.btnDogadaj.Text = "Događaji";
            this.btnDogadaj.UseVisualStyleBackColor = true;
            this.btnDogadaj.Click += new System.EventHandler(this.btnDogadaj_Click);
            // 
            // btnUnesiLog
            // 
            this.btnUnesiLog.Location = new System.Drawing.Point(356, 586);
            this.btnUnesiLog.Name = "btnUnesiLog";
            this.btnUnesiLog.Size = new System.Drawing.Size(100, 26);
            this.btnUnesiLog.TabIndex = 9;
            this.btnUnesiLog.Text = "Unesi log";
            this.btnUnesiLog.UseVisualStyleBackColor = true;
            this.btnUnesiLog.Click += new System.EventHandler(this.btnUnesiLog_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 570);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Temperatura:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(201, 571);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "Vlaga:";
            // 
            // btnNatrag
            // 
            this.btnNatrag.Location = new System.Drawing.Point(12, 12);
            this.btnNatrag.Name = "btnNatrag";
            this.btnNatrag.Size = new System.Drawing.Size(70, 37);
            this.btnNatrag.TabIndex = 13;
            this.btnNatrag.Text = "<=";
            this.btnNatrag.UseVisualStyleBackColor = true;
            this.btnNatrag.Click += new System.EventHandler(this.btnNatrag_Click);
            // 
            // btnPovijest
            // 
            this.btnPovijest.Location = new System.Drawing.Point(850, 12);
            this.btnPovijest.Name = "btnPovijest";
            this.btnPovijest.Size = new System.Drawing.Size(128, 38);
            this.btnPovijest.TabIndex = 14;
            this.btnPovijest.Text = "Povijest biljke";
            this.btnPovijest.UseVisualStyleBackColor = true;
            this.btnPovijest.Click += new System.EventHandler(this.btnPovijest_Click);
            // 
            // BiljkeMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 635);
            this.Controls.Add(this.btnPovijest);
            this.Controls.Add(this.btnNatrag);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUnesiLog);
            this.Controls.Add(this.btnDogadaj);
            this.Controls.Add(this.btnSlike);
            this.Controls.Add(this.btnObrisiBiljku);
            this.Controls.Add(this.btnAzurirajBiljku);
            this.Controls.Add(this.btnDodajBiljku);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "BiljkeMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BiljkeMain";
            this.Load += new System.EventHandler(this.BiljkeMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnDodajBiljku;
        private System.Windows.Forms.Button btnAzurirajBiljku;
        private System.Windows.Forms.Button btnObrisiBiljku;
        private System.Windows.Forms.Button btnSlike;
        private System.Windows.Forms.Button btnDogadaj;
        private System.Windows.Forms.Button btnUnesiLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnNatrag;
        private System.Windows.Forms.Button btnPovijest;
    }
}