﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using NpgsqlTypes;
using System.Data.SqlTypes;


namespace TBP_verzija_2
{
    public partial class FormDogadaj : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        
        public FormDogadaj()
        {
            InitializeComponent();
        }

        private void FormDogadaj_Load(object sender, EventArgs e)
        {
            PopuniComboBiljke();
            PopuniComboTipovi();
            DohvatiSveDogadaje();
        }

        private void DohvatiSveDogadaje()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT d.dogadaj_id, b.ime AS biljka, d.tip, d.datum 
                                 FROM dogadaj d
                                 JOIN biljka b ON d.biljka_id = b.biljka_id";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            dgvDogadaji.DataSource = dataTable;
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom učitavanja događaja: " + ex.Message);
            }
        }

        private void PopuniComboTipovi()
        {
            try
            {
                comboBoxTipovi.Items.AddRange(new string[] { "Zalijevanje", "Prihranjivanje", "Presađivanje" });
                comboBoxTipovi.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom učitavanja tipova događaja: " + ex.Message);
            }
        }

        private void PopuniComboBiljke()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT biljka_id, ime FROM biljka";
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            comboBoxBiljke.DataSource = dataTable;
                            comboBoxBiljke.DisplayMember = "ime";
                            comboBoxBiljke.ValueMember = "biljka_id";
                        }
                    }
                       
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom učitavanja biljaka: " + ex.Message);
            }
        }

        
        private void btnDodaj_Click(object sender, EventArgs e)
        {
            int biljkaId = Convert.ToInt32(comboBoxBiljke.SelectedValue);
            string tip = comboBoxTipovi.SelectedItem.ToString();
            DateTime datum = dateTimePicker1.Value.Date;

            
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO dogadaj (biljka_id, datum, tip) VALUES (@biljkaId, @datum, @tipDogadaja::dogadaj_tip)";
                    
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", biljkaId);
                        cmd.Parameters.AddWithValue("@datum", datum);
                        cmd.Parameters.AddWithValue("@tipDogadaja", tip);

                        cmd.ExecuteNonQuery();
                    }
                }

                DohvatiSveDogadaje();

                MessageBox.Show("Događaj uspješno dodan.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom dodavanja događaja: " + ex.Message);
            }
        }

        private void btnNatrag_Click(object sender, EventArgs e)
        {
            this.DialogResult=DialogResult.OK;
            this.Close();
        }

        private void btnFiltriraj_Click(object sender, EventArgs e)
        {
            int biljkaId = Convert.ToInt32(comboBoxBiljke.SelectedValue);
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT d.dogadaj_id, b.ime AS biljka, d.tip, d.datum 
                             FROM dogadaj d
                             JOIN biljka b ON d.biljka_id = b.biljka_id
                             WHERE d.biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", biljkaId);

                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            dgvDogadaji.DataSource = dataTable;
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }
    }
}
