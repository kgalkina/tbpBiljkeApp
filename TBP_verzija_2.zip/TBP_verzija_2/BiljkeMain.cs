﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class BiljkeMain : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        private int odabranaBiljka = 0;
        
        public BiljkeMain()
        {
            InitializeComponent();
            
            
        }

        private void BiljkeMain_Load(object sender, EventArgs e)
        {
            DohvatiBiljke();
            
            
        }

        private void DohvatiBiljke()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    var query = "SELECT * FROM biljka";

                    using (var adapter = new NpgsqlDataAdapter(query, conn))
                    {
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch
            {

                MessageBox.Show("Greška");
            }
        }
        private void DohvatiLogove(int biljkaId)
        {
            if (biljkaId == 0) return;
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    var query = "SELECT * FROM dnevni_log WHERE biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", biljkaId);

                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            var dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            dataGridView2.DataSource = dataTable;
                        }
                    }
                }
            }
            catch 
            {

                MessageBox.Show("greška");
            }

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                if (selectedRow.Cells["biljka_id"].Value != DBNull.Value)
                {
                    odabranaBiljka = Convert.ToInt32(selectedRow.Cells["biljka_id"].Value);
                    DohvatiLogove(odabranaBiljka); 
                }
            }
        }

        

        private void btnUnesiLog_Click(object sender, EventArgs e)
        {
            if (!float.TryParse(textBox1.Text, out float temperatura) ||
            !int.TryParse(textBox2.Text, out int vlaga))
            {
                MessageBox.Show("Unesite ispravne vrijednosti.");
                return;
            }
            if (odabranaBiljka == 0)
            {
                MessageBox.Show("Odaberite biljku prije unosa loga.");
                return;
            }
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO dnevni_log (biljka_id, temperaturaDanas, vlagaDanas) VALUES (@biljkaId, @temperatura, @vlaga)";
                    
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", odabranaBiljka);
                        cmd.Parameters.AddWithValue("@temperatura", temperatura);
                        cmd.Parameters.AddWithValue("@vlaga", vlaga);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Dnevni log uspješno dodan.");
                        DohvatiLogove(odabranaBiljka);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Greška prilikom dodavanja loga: " + ex.Message);
            }
            
        }

        private void btnSlike_Click(object sender, EventArgs e)
        {
            if (odabranaBiljka != 0)
            {
                FormaSlike formaSlike = new FormaSlike(odabranaBiljka);
                formaSlike.ShowDialog();
            }
            else
            {
                MessageBox.Show("Odaberi biljku.");
            }
            
        }

        private void btnDodajBiljku_Click(object sender, EventArgs e)
        {
            DodajBiljku formaDodaj = new DodajBiljku();
            formaDodaj.ShowDialog();
            if (formaDodaj.DialogResult == DialogResult.OK)
            {
                DohvatiBiljke();
            }
            
        }

        private void btnObrisiBiljku_Click(object sender, EventArgs e)
        {
            if (odabranaBiljka == 0)
            {
                MessageBox.Show("biljka nije odabrana.");
                return;
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Jeste li sigurni da želite obrisati odabranu biljku?", "Potvrda brisanja", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        using (var conn = new NpgsqlConnection(connectionString))
                        {
                            conn.Open();

                            string query = "DELETE FROM biljka WHERE biljka_id = @biljkaId";

                            using (var cmd = new NpgsqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@biljkaId", odabranaBiljka);
                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Biljka je uspješno obrisana.");
                            }
                            
                        }

                        DohvatiBiljke();
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Greška prilikom brisanja biljke: " + ex.Message);
                    }
                }
            }
            
        }

        private void btnAzurirajBiljku_Click(object sender, EventArgs e)
        {
            AzurirajBiljkuForma azuriraj=new AzurirajBiljkuForma(odabranaBiljka);
            azuriraj.ShowDialog();
            if (azuriraj.DialogResult == DialogResult.OK)
            {
                DohvatiBiljke();
            }
        }

        private void btnDogadaj_Click(object sender, EventArgs e)
        {
            FormDogadaj dogadaj=new FormDogadaj();
            dogadaj.ShowDialog();
            if (dogadaj.DialogResult == DialogResult.OK)
            {
                DohvatiBiljke();
            }
        }

        private void btnNatrag_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
            

        }

        private void btnPovijest_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int biljkaId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["biljka_id"].Value);
                FormBiljkaPovijest povijest = new FormBiljkaPovijest(biljkaId);
                povijest.ShowDialog();
            }
            else
            {
                MessageBox.Show("Odaberite biljku iz tablice.");
            }
        }
    }
}

        
    
    

