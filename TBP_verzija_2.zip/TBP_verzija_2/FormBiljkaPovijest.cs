﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class FormBiljkaPovijest : Form
    {
        
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";
        private int odabrana;
        public FormBiljkaPovijest(int biljkaId)
        {
            InitializeComponent();
            odabrana = biljkaId;
        }

        private void FormBiljkaPovijest_Load(object sender, EventArgs e)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"SELECT * FROM biljka_povijest WHERE biljka_id = @biljkaId";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@biljkaId", odabrana);

                        using (var adapter = new NpgsqlDataAdapter(cmd))
                        {
                            DataTable povijestTable = new DataTable();
                            adapter.Fill(povijestTable);

                            dataGridView1.DataSource = povijestTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }

        private void btnNatrag_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
