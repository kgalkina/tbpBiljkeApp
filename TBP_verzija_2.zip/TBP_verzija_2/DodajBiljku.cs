﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace TBP_verzija_2
{
    public partial class DodajBiljku : Form
    {
        private readonly string connectionString = "Host=localhost;Username=postgres;Password=postgres;Database=BAZA_TBP";

        public DodajBiljku()
        {
            InitializeComponent();
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"INSERT INTO biljka (ime, vrsta, datum_sadnje, zalijevanje, prihranjivanje, presadivanje, 
                                min_temp, max_temp, min_vlaga, max_vlaga, dodatno)
                                VALUES (@ime, @vrsta, @datumSadnje, @zalijevanje, @prihranjivanje, @presadivanje,
                                @minTemp, @maxTemp, @minVlaga, @maxVlaga, @dodatno)";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ime", textBox1.Text);
                        cmd.Parameters.AddWithValue("@vrsta", textBox2.Text);
                        cmd.Parameters.AddWithValue("@datumSadnje", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@zalijevanje", int.Parse(textBox3.Text));
                        cmd.Parameters.AddWithValue("@prihranjivanje", int.Parse(textBox4.Text));
                        cmd.Parameters.AddWithValue("@presadivanje", int.Parse(textBox5.Text));
                        cmd.Parameters.AddWithValue("@minTemp", float.Parse(textBox6.Text));
                        cmd.Parameters.AddWithValue("@maxTemp", float.Parse(textBox7.Text));
                        cmd.Parameters.AddWithValue("@minVlaga", int.Parse(textBox8.Text));
                        cmd.Parameters.AddWithValue("@maxVlaga", int.Parse(textBox9.Text));
                        cmd.Parameters.AddWithValue("@dodatno", textBox10.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Biljka uspješno dodana.");
                        this.DialogResult = DialogResult.OK;
                        this.Close(); 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška prilikom dodavanja biljke: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
